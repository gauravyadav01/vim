# ubuntu-bash-for-windows

Combined a vbs script that installs the fonts that are present in the current directory in Windows 10 with a PowerShell script that modifies the apperance of the 'Ubuntu on Windows' bash to look like its counterpart in the original Ubuntu. Settings for this found on https://medium.com/@jgarijogarde/make-bash-on-ubuntu-on-windows-10-look-like-the-ubuntu-terminal-f7566008c5c2 and fonts are from http://font.ubuntu.com/ .
